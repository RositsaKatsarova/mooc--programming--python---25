# Write your solution here
print(":-)")